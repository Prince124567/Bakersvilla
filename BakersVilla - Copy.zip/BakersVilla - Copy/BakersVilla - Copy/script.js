var navLinks = document.getElementById("navLinks")

        function show(){
            navLinks.style.right = "0";
        }
        function hiden(){
            navLinks.style.right = "-200px";
        }